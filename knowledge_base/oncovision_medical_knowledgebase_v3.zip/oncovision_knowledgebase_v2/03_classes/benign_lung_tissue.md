# CLASS: Benign Lung Tissue

## Label semantics
This is the LC25000 benign lung tissue class.

## Educational morphology
Possible structures include alveolar spaces, thin septa, type I/II pneumocytes, macrophages, bronchiolar structures and vessels.

## Critical nuance
This class should not be described as "no disease." The dataset label is a classification category and may not cover the full spectrum of inflammatory, infectious, fibrotic or other pulmonary pathology.

## Differential
- lung adenocarcinoma,
- squamous cell carcinoma,
- inflammatory/reactive change,
- fibrosis,
- edema,
- infection,
- artifact.

## Sources
- NCBI Histology, Lung: https://www.ncbi.nlm.nih.gov/books/NBK534789/
- LC25000: https://arxiv.org/abs/1912.12142
