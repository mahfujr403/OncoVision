# CLASS: Benign Colonic Tissue

## Label semantics
This class corresponds to the LC25000 "benign colon tissue" category.

## Expected educational pattern
Normal colonic mucosa can show organized crypts, lamina propria, surface epithelium and abundant goblet cells.

## Critical nuance
The dataset label is not synonymous with "all benign colorectal pathology." Adenomas and serrated lesions are distinct pathologic entities; some are premalignant. The AI should not claim that a benign-class prediction excludes every lesion or disease.

## Differential concepts
- normal mucosa,
- inflammatory/reactive change,
- conventional adenoma,
- serrated lesion,
- poorly oriented crypts,
- carcinoma.

## Sources
- LC25000: https://arxiv.org/abs/1912.12142
- NCBI normal colon morphology: https://www.ncbi.nlm.nih.gov/books/NBK1566/figure/A291/
- PMC normal colon microanatomy: https://pmc.ncbi.nlm.nih.gov/articles/PMC12278992/
- PMC serrated lesions: https://pmc.ncbi.nlm.nih.gov/articles/PMC8299322/
