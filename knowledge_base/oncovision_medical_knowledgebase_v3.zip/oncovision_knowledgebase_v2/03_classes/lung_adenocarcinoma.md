# CLASS: Lung Adenocarcinoma

## Label semantics
This class corresponds to LC25000 lung adenocarcinoma.

## Educational morphology
Possible features include glandular/acinar, papillary, lepidic, micropapillary or solid growth patterns. Mucinous differentiation may occur.

## Differential
- benign lung tissue,
- squamous cell carcinoma,
- other NSCLC,
- metastatic adenocarcinoma,
- poorly differentiated carcinoma.

## IHC context
TTF-1 and Napsin A can support pulmonary adenocarcinoma in an appropriate differential; p40 supports squamous differentiation.

## Sources
- NCBI Lung Adenocarcinoma: https://www.ncbi.nlm.nih.gov/books/NBK519578/
- PMC Lung Adenocarcinoma Histology: https://pmc.ncbi.nlm.nih.gov/articles/PMC4367552/
- PMC Lung IHC best practices: https://pmc.ncbi.nlm.nih.gov/articles/PMC6422775/
- LC25000: https://arxiv.org/abs/1912.12142
