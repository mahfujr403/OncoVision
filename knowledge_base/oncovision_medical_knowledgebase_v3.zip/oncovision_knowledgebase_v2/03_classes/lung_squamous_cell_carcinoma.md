# CLASS: Lung Squamous Cell Carcinoma

## Label semantics
This is the LC25000 lung squamous cell carcinoma class.

## Educational morphology
Supportive features include squamous differentiation, keratinization, intercellular bridges and keratin pearls in suitable tumors. Poorly differentiated examples may show limited obvious squamous maturation.

## Differential
- lung adenocarcinoma,
- poorly differentiated NSCLC,
- benign/reactive bronchial epithelium,
- other carcinomas.

## IHC context
p40 is a key squamous marker; CK5/6 can support squamous differentiation. TTF-1/Napsin A support adenocarcinoma in the appropriate setting.

## Sources
- NCBI Squamous Cell Lung Cancer: https://www.ncbi.nlm.nih.gov/books/NBK564510/
- NCI NSCLC PDQ: https://www.cancer.gov/types/lung/hp/non-small-cell-lung-treatment-pdq
- PMC Lung IHC best practices: https://pmc.ncbi.nlm.nih.gov/articles/PMC6422775/
- LC25000: https://arxiv.org/abs/1912.12142
