# CLASS: Colon Adenocarcinoma

## Label semantics
This is one of the five LC25000 classes and represents histopathologic images labeled as colon adenocarcinoma.

## Strong educational concepts
- malignant gland-forming epithelial neoplasm,
- irregular/destructive glands,
- atypical epithelial cells,
- stromal reaction/desmoplasia,
- possible luminal necrotic debris,
- possible cribriform/fused gland architecture,
- possible mucinous or other variant morphology.

## Common confusion
- normal/benign colonic crypts,
- adenomatous/dysplastic glands,
- serrated lesions,
- inflammation/reactive atypia,
- tangentially sectioned or poorly oriented benign glands.

## What RAG can explain
- what colon adenocarcinoma means,
- typical histologic features,
- why it differs from benign colon tissue,
- why molecular/IHC testing may be performed,
- what pathology reports may contain.

## What RAG must not infer
- exact TNM stage,
- margin status,
- lymph-node status,
- molecular mutation,
- prognosis for an individual,
- treatment recommendation.

## Sources
- NCBI StatPearls Colon Cancer: https://www.ncbi.nlm.nih.gov/books/NBK470380/
- NCBI Bookshelf Adenocarcinoma of the Colon and Rectum: https://www.ncbi.nlm.nih.gov/books/NBK13888/
- NCI Colon Cancer PDQ: https://www.cancer.gov/types/colorectal/hp/colon-treatment-pdq
- CAP Current Cancer Protocols: https://www.cap.org/protocols-and-guidelines/cancer-reporting-tools/cancer-protocol-templates
