# Source Metadata and Recommended Priority

| Source | Tier | Best use | Freshness |
|---|---|---|---|
| NCI PDQ | 1 | Current disease/treatment context | Update regularly |
| CAP protocols | 1 | Pathology reporting elements | Update when protocol changes |
| NCBI Bookshelf/StatPearls | 2 | Broad disease/pathology explanations | Check update date |
| PMC reviews | 3 | Detailed morphology/differentials | Prefer newer reviews where available |
| OpenStax | 4 | Basic anatomy/histology | Stable |
| LC25000 original paper/repository | Dataset | Label semantics/data provenance | Stable |

## Update policy
Clinical treatment and biomarker information can change. Maintain a `last_reviewed` field in your production chunk metadata and periodically review NCI/CAP sources.

## Legal/access note
The corpus links to free-to-access sources. Source copyright/licensing terms still apply. The corpus is a factual summary and does not reproduce source articles verbatim.
