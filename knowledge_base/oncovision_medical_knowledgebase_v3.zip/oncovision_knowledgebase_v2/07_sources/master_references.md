# Master References

## Tier 1 — Official / authoritative

### National Cancer Institute
- What Is Cancer? https://www.cancer.gov/about-cancer/understanding/what-is-cancer
- Diagnosis: https://www.cancer.gov/about-cancer/diagnosis-staging/diagnosis
- Staging: https://www.cancer.gov/about-cancer/diagnosis-staging/staging
- Pathology Reports: https://www.cancer.gov/about-cancer/diagnosis-staging/diagnosis/pathology-reports-fact-sheet
- Biomarker: https://www.cancer.gov/publications/dictionaries/cancer-terms/def/biomarker
- Biomarker Testing: https://www.cancer.gov/publications/dictionaries/cancer-terms/def/biomarker-testing
- Immunohistochemistry: https://www.cancer.gov/publications/dictionaries/cancer-terms/def/immunohistochemistry
- Types of Treatment: https://www.cancer.gov/about-cancer/treatment/types
- Colon Cancer PDQ: https://www.cancer.gov/types/colorectal/hp/colon-treatment-pdq
- NSCLC PDQ: https://www.cancer.gov/types/lung/hp/non-small-cell-lung-treatment-pdq

### CAP
- Current Cancer Protocols: https://www.cap.org/protocols-and-guidelines/cancer-reporting-tools/cancer-protocol-templates
- Cancer Protocols overview: https://www.cap.org/protocols-and-guidelines/cancer-protocols/

## Tier 2 — NCBI Bookshelf / NIH
- Colon Cancer, StatPearls: https://www.ncbi.nlm.nih.gov/books/NBK470380/
- Lung Adenocarcinoma, StatPearls: https://www.ncbi.nlm.nih.gov/books/NBK519578/
- Squamous Cell Lung Cancer, StatPearls: https://www.ncbi.nlm.nih.gov/books/NBK564510/
- Histology, Lung: https://www.ncbi.nlm.nih.gov/books/NBK534789/
- Histology, Goblet Cells: https://www.ncbi.nlm.nih.gov/books/NBK553208/
- Adenocarcinoma of the Colon and Rectum: https://www.ncbi.nlm.nih.gov/books/NBK13888/
- Principles of Cancer Pathology: https://www.ncbi.nlm.nih.gov/books/NBK13899/
- Normal colon morphology figure: https://www.ncbi.nlm.nih.gov/books/NBK1566/figure/A291/

## Tier 3 — Peer-reviewed open-access / PMC
- Best Practices Recommendations for Diagnostic IHC in Lung Cancer: https://pmc.ncbi.nlm.nih.gov/articles/PMC6422775/
- TTF-1/Napsin A/p40/CK5 differential study: https://pmc.ncbi.nlm.nih.gov/articles/PMC4467219/
- Histomorphological and molecular landscape of colorectal adenomas and serrated lesions: https://pmc.ncbi.nlm.nih.gov/articles/PMC8299322/
- Up-to-date review of serrated lesions: https://pmc.ncbi.nlm.nih.gov/articles/PMC10955069/
- Evolving pathologic concepts of serrated lesions: https://pmc.ncbi.nlm.nih.gov/articles/PMC7385269/
- Pulmonary Adenocarcinoma Histology: https://pmc.ncbi.nlm.nih.gov/articles/PMC4367552/
- Physiology of lower GI tract / normal colon microanatomy: https://pmc.ncbi.nlm.nih.gov/articles/PMC12278992/

## Tier 4 — Open educational sources
- OpenStax Epithelial Tissue: https://openstax.org/books/anatomy-and-physiology-2e/pages/4-2-epithelial-tissue

## Dataset source
- LC25000 paper: https://arxiv.org/abs/1912.12142
- LC25000 original repository: https://github.com/tampapath/lung_colon_image_set
- LC25000 dataset description: https://github.com/openmedlab/Awesome-Medical-Dataset/blob/main/resources/LC25000.md
