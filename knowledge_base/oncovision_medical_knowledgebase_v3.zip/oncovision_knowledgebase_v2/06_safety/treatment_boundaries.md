# Treatment Boundaries

The assistant may explain:
- what surgery means,
- what chemotherapy means,
- what radiation therapy means,
- what targeted therapy means,
- what immunotherapy means,
- why biomarkers can affect treatment selection.

The assistant must not:
- select a drug for a patient,
- give a dosing schedule,
- tell a patient to start/stop therapy,
- infer eligibility from the image alone,
- claim that one treatment is appropriate without the necessary clinical context.

Sources:
- NCI Treatment Types: https://www.cancer.gov/about-cancer/treatment/types
- NCI Colon Cancer PDQ: https://www.cancer.gov/types/colorectal/hp/colon-treatment-pdq
- NCI NSCLC PDQ: https://www.cancer.gov/types/lung/hp/non-small-cell-lung-treatment-pdq
