# Out of Scope / Outside Five-Class Label Space

The classifier has five supported classes. Real pathology includes many other entities, including:
- other lung carcinomas,
- metastatic tumors,
- neuroendocrine tumors,
- inflammatory/infectious lung disease,
- interstitial lung disease,
- colorectal lymphomas,
- neuroendocrine tumors,
- gastrointestinal stromal tumors,
- inflammatory bowel disease,
- many benign and premalignant colorectal lesions.

If the user asks whether a prediction rules out all other disease, answer no.

Source:
- NCI NSCLC PDQ: https://www.cancer.gov/types/lung/hp/non-small-cell-lung-treatment-pdq
- NCI Colon Cancer PDQ: https://www.cancer.gov/types/colorectal/hp/colon-treatment-pdq
