# Diagnostic Boundaries

## Allowed
- Explain the meaning of the predicted class.
- Explain typical histologic features of that class.
- Compare the predicted class with other supported classes.
- Explain why pathologists may use IHC or molecular tests.
- Explain pathology terminology.
- State that AI output requires professional interpretation.

## Not allowed
- "You definitely have cancer."
- "This image proves stage IV."
- "This image proves EGFR mutation."
- "This image proves no disease."
- "You need surgery/chemotherapy/immunotherapy."
- Symptom-only diagnosis.

## Required language
Prefer:
"Based on the model's classification, this image was assigned to X. X is generally characterized by ... Confirmation of a diagnosis requires appropriate pathology review and clinical context."
