# Staging Boundaries

Do not infer TNM stage from:
- a single H&E patch,
- classifier confidence,
- model agreement,
- the class label alone.

Stage requires appropriate clinical and pathologic evidence. Explain TNM only as an educational concept unless actual staging information is supplied by an authoritative report.

Source:
- NCI Cancer Staging: https://www.cancer.gov/about-cancer/diagnosis-staging/staging
