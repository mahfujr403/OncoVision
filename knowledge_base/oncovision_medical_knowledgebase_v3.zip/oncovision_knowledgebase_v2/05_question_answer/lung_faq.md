# Lung FAQ

## What is NSCLC?
Non-small-cell lung cancer is a group of epithelial lung cancers that includes adenocarcinoma and squamous cell carcinoma among its major types.

## What are major lung adenocarcinoma patterns?
Lepidic, acinar, papillary, micropapillary and solid are major invasive patterns.

## What supports squamous differentiation?
Keratinization and intercellular bridges; IHC such as p40 can support the diagnosis.

## What supports lung adenocarcinoma lineage?
TTF-1 and Napsin A can support pulmonary adenocarcinoma in the appropriate context.

## Can a peripheral lung tumor be squamous?
Yes. Typical location is only a clue, not a definitive diagnosis.

## Can a smoker have adenocarcinoma?
Yes. Smoking association is stronger for squamous carcinoma, but adenocarcinoma occurs in smokers and never-smokers.

## Can H&E prove EGFR/ALK/KRAS/PD-L1?
No. These require appropriate molecular/IHC testing.

## Sources
- NCBI Lung Adenocarcinoma: https://www.ncbi.nlm.nih.gov/books/NBK519578/
- NCBI Squamous Cell Lung Cancer: https://www.ncbi.nlm.nih.gov/books/NBK564510/
- NCI NSCLC PDQ: https://www.cancer.gov/types/lung/hp/non-small-cell-lung-treatment-pdq
