# General FAQ

## What is cancer?
Cancer is a group of diseases involving uncontrolled abnormal cell growth, with potential invasion and spread.

## What is a benign tumor?
A benign tumor is non-malignant. However, benign does not always mean harmless, and a dataset's "benign tissue" label is narrower than all benign disease.

## What is carcinoma?
A malignant neoplasm arising from epithelial cells.

## What is adenocarcinoma?
A carcinoma showing glandular differentiation.

## What is histopathology?
Microscopic evaluation of tissue structure and cellular morphology.

## What is H&E?
Hematoxylin and eosin, a routine tissue stain used to visualize morphology.

## What is IHC?
Immunohistochemistry uses antibodies to detect proteins in tissue.

## Can H&E alone tell molecular mutation status?
No. Molecular status generally requires an appropriate laboratory test.

## Can one patch establish cancer stage?
No. Staging requires broader anatomic/pathologic/clinical information.

## Sources
- NCI Cancer Basics: https://www.cancer.gov/about-cancer/understanding/what-is-cancer
- NCI Cancer Staging: https://www.cancer.gov/about-cancer/diagnosis-staging/staging
- NCI IHC: https://www.cancer.gov/publications/dictionaries/cancer-terms/def/immunohistochemistry
