# Colon FAQ

## What is the most common malignant epithelial tumor of the colon?
Adenocarcinoma is the predominant colonic malignancy.

## What does normal colon look like microscopically?
Organized crypts lined by epithelium, with prominent goblet cells and lamina propria.

## What is a hyperplastic polyp?
A common serrated lesion with characteristic serrated architecture, usually lacking the dysplastic architectural features of SSLs.

## What is an SSL?
A sessile serrated lesion is a serrated colorectal lesion characterized by characteristic crypt architectural abnormalities and recognized as an important precursor lesion.

## What is tumor budding?
Small clusters or single tumor cells at the invasive front; it is a pathologic feature that may carry prognostic significance.

## Can an image prove MMR/MSI status?
No.

## Can a colon adenocarcinoma patch prove TNM stage?
No.

## Sources
- NCBI Colon Cancer: https://www.ncbi.nlm.nih.gov/books/NBK470380/
- PMC Serrated Lesions: https://pmc.ncbi.nlm.nih.gov/articles/PMC10955069/
- NCI Colon Cancer PDQ: https://www.cancer.gov/types/colorectal/hp/colon-treatment-pdq
