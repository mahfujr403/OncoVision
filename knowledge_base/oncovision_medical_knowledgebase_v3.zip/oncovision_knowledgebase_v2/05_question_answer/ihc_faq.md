# IHC FAQ

## Is TTF-1 specific for every lung adenocarcinoma?
No. It is a useful marker but not universally expressed and must be interpreted in context.

## Is p40 specific for every squamous carcinoma?
It is a strong squamous marker, but interpretation depends on staining pattern, extent, morphology and differential diagnosis.

## Why use a panel instead of one marker?
Tumors are heterogeneous and markers have imperfect sensitivity/specificity. A focused panel improves classification when morphology is insufficient.

## What is the recommended basic lung subtyping concept?
A focused TTF-1/p40 approach is widely recommended for NSCLC subtyping when IHC is needed, with additional markers as appropriate.

## Sources
- PMC Best Practices Diagnostic IHC in Lung Cancer: https://pmc.ncbi.nlm.nih.gov/articles/PMC6422775/
- PMC TTF-1/Napsin A/p40/CK5 study: https://pmc.ncbi.nlm.nih.gov/articles/PMC4467219/
