# Colon Adenocarcinoma — Variants, Invasion and Reporting Concepts

## Variants
Relevant morphologic patterns include:
- mucinous adenocarcinoma,
- signet-ring cell morphology,
- medullary features,
- micropapillary architecture,
- serrated morphology in selected tumors.

## Invasion-related features
Depending on specimen and protocol, pathologic evaluation may address:
- depth of invasion,
- lymphovascular invasion,
- perineural invasion,
- tumor deposits,
- regional lymph nodes,
- margins,
- tumor budding,
- perforation/serosal involvement.

## Why this matters to OncoVision
Many of these features require a larger specimen and tissue context. A single image patch cannot establish them reliably.

## Sources
- CAP, Current Cancer Protocols: https://www.cap.org/protocols-and-guidelines/cancer-reporting-tools/cancer-protocol-templates
- NCI Colon Cancer PDQ: https://www.cancer.gov/types/colorectal/hp/colon-treatment-pdq
- NCBI StatPearls Colon Cancer: https://www.ncbi.nlm.nih.gov/books/NBK470380/
