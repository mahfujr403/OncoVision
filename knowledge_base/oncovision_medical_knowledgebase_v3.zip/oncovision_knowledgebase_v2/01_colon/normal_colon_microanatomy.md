# Normal Colon Microanatomy

## Core structures
Normal colonic mucosa contains:
- surface epithelium,
- straight tubular crypts of Lieberkühn,
- lamina propria,
- muscularis mucosae.

The colon also contains submucosa and muscularis externa; depending on location, the outer surface is associated with serosa/adventitia.

## Cell types
Goblet cells are prominent and produce mucus. Absorptive colonocytes are another major epithelial population. Crypt bases contain proliferative stem/progenitor compartments.

## Histologic orientation
Normal crypts are generally organized and parallel, extending from the surface toward the muscularis mucosae. The architecture and maturation gradient are important when comparing normal/benign tissue with dysplasia and carcinoma.

## Sources
- NCBI Bookshelf, Normal colon morphology: https://www.ncbi.nlm.nih.gov/books/NBK1566/figure/A291/
- PMC, Physiology of lower gastrointestinal tract / normal colon microanatomy: https://pmc.ncbi.nlm.nih.gov/articles/PMC12278992/
- NCBI StatPearls, Goblet Cells: https://www.ncbi.nlm.nih.gov/books/NBK553208/
