# Colon Adenocarcinoma — Molecular and IHC Context

## MMR/MSI
Mismatch-repair deficiency and microsatellite instability are important colorectal cancer biomarkers. They can affect hereditary cancer assessment and treatment context.

## RAS/BRAF/HER2
Depending on disease setting, molecular testing may include KRAS/NRAS, BRAF and HER2 among other biomarkers.

## IHC
IHC can support differential diagnosis and may be used for mismatch-repair protein evaluation (e.g., MLH1, PMS2, MSH2, MSH6) or lineage questions. Marker panels must be interpreted with morphology and clinical context.

## Source
- NCI Colon Cancer PDQ: https://www.cancer.gov/types/colorectal/hp/colon-treatment-pdq
- CAP Colon and Rectum Biomarker Reporting: https://www.cap.org/protocols-and-guidelines/cancer-reporting-tools/cancer-protocol-templates
- NCI Biomarker Testing: https://www.cancer.gov/publications/dictionaries/cancer-terms/def/biomarker-testing
