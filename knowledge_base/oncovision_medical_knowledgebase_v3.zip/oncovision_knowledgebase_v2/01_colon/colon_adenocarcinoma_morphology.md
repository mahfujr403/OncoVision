# Colon Adenocarcinoma — Histomorphology

## Core definition
Colon adenocarcinoma is the predominant malignant epithelial tumor of the colon.

## Morphologic concepts
Features that can support invasive adenocarcinoma include:
- malignant gland formation,
- irregular or angulated glands,
- destructive infiltration into surrounding stroma,
- cytologic atypia,
- dirty necrosis in glandular lumina in appropriate cases,
- desmoplastic stromal response,
- cribriform or fused gland architecture,
- tumor budding at an invasive front.

## Histologic variants/context
Colorectal adenocarcinoma can show mucinous, signet-ring, medullary, micropapillary and other patterns. A tumor may be heterogeneous.

## Important distinction
Adenocarcinoma is not simply "many glands." Benign glands can be crowded or distorted by technical factors or inflammation. Invasion and cytologic/architectural context matter.

## Sources
- NCBI StatPearls, Colon Cancer: https://www.ncbi.nlm.nih.gov/books/NBK470380/
- NCBI Bookshelf, Adenocarcinoma of the Colon and Rectum: https://www.ncbi.nlm.nih.gov/books/NBK13888/
- NCI Colon Cancer PDQ: https://www.cancer.gov/types/colorectal/hp/colon-treatment-pdq
