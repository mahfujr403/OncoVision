# Benign Colonic Tissue, Polyps and Precursor Lesions

## Dataset meaning
The LC25000 label is "benign colon tissue". It should be treated as a dataset-level category, not as a universal label for every benign colorectal lesion.

## Common benign/precursor categories
- normal colonic mucosa,
- conventional adenomas,
- hyperplastic polyps,
- sessile serrated lesions,
- traditional serrated adenomas.

These are not interchangeable.

## Conventional adenomas
Tubular, tubulovillous and villous architecture are classic adenoma patterns. Dysplasia is a key concept in conventional adenomas.

## Serrated lesions
Serrated lesions include hyperplastic polyps, sessile serrated lesions (SSLs), and traditional serrated adenomas (TSAs). SSLs and TSAs can be important precursor lesions for colorectal carcinoma.

## Sources
- PMC, Histomorphological and molecular landscape of colorectal adenomas and serrated lesions: https://pmc.ncbi.nlm.nih.gov/articles/PMC8299322/
- PMC, Up-to-date review of serrated lesions: https://pmc.ncbi.nlm.nih.gov/articles/PMC10955069/
- PMC, Evolving pathologic concepts of serrated lesions: https://pmc.ncbi.nlm.nih.gov/articles/PMC7385269/
