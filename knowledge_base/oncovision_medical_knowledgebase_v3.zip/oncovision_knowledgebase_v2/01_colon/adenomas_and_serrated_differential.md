# Colonic Adenoma and Serrated-Lesion Differential

## Hyperplastic polyp
Typical features include serration concentrated in upper crypts, relatively orderly architecture and mature goblet-cell-rich epithelium.

## Sessile serrated lesion
Key clues include architectural distortion, especially basal crypt dilation/branching and abnormal crypt shapes. The distinction from hyperplastic polyps can be difficult, particularly in small or poorly oriented biopsies.

## Traditional serrated adenoma
Can show serrated architecture with dysplastic cytologic features and characteristic elongated, ectopic or ectopic crypt architecture depending on the lesion.

## Conventional adenoma
Dysplastic epithelium and tubular/villous architecture distinguish conventional adenomatous lesions from normal mucosa.

## Retrieval caution
Do not turn a short image description into a definitive polyp subtype. Some distinctions require adequate sampling, orientation and expert pathology review.

## Sources
- PMC, Serrated lesions: https://pmc.ncbi.nlm.nih.gov/articles/PMC3629844/
- PMC, Histomorphological/molecular landscape: https://pmc.ncbi.nlm.nih.gov/articles/PMC8299322/
- PMC, Up-to-date serrated review: https://pmc.ncbi.nlm.nih.gov/articles/PMC10955069/
