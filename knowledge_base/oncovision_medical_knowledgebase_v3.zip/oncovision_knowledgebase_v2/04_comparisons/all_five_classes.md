# All Five OncoVision Classes — Comparison Matrix

| Class | Organ | Broad category | Main educational clues |
|---|---|---|---|
| Colon adenocarcinoma | Colon | Malignant epithelial | Irregular/destructive gland formation, atypia, invasion/desmoplasia |
| Benign colonic tissue | Colon | Benign/dataset category | Organized crypts, goblet cells, preserved architecture |
| Lung adenocarcinoma | Lung | Malignant epithelial | Glandular/lepidic/acinar/papillary/micropapillary/solid patterns |
| Benign lung tissue | Lung | Benign/dataset category | Alveoli, thin septa, pneumocytes, macrophages, airway structures |
| Lung squamous cell carcinoma | Lung | Malignant epithelial | Squamous differentiation, keratinization, intercellular bridges |

## Highest-value pairwise differentials
1. Colon benign vs colon adenocarcinoma
2. Lung benign vs lung adenocarcinoma
3. Lung benign vs lung squamous cell carcinoma
4. Lung adenocarcinoma vs lung squamous cell carcinoma
5. Colon tissue vs lung tissue

## Important caveat
The model's label space is narrower than real-world pathology. Many real diagnoses are outside these five classes.
