# Colon Benign Tissue vs Colon Adenocarcinoma

## Benign/normal tendency
- organized crypt architecture,
- orderly maturation,
- preserved mucosal organization,
- abundant goblet cells,
- no destructive stromal invasion.

## Adenocarcinoma tendency
- irregular/fused/cribriform glands,
- cytologic atypia,
- destructive invasion,
- desmoplastic response,
- possible luminal necrotic debris.

## Failure modes
- tangential sectioning,
- inflammation,
- reactive atypia,
- poorly oriented biopsy,
- adenomatous/dysplastic lesions that are not invasive carcinoma.

## Sources
- NCBI Colon Cancer: https://www.ncbi.nlm.nih.gov/books/NBK470380/
- NCBI Normal colon morphology: https://www.ncbi.nlm.nih.gov/books/NBK1566/figure/A291/
