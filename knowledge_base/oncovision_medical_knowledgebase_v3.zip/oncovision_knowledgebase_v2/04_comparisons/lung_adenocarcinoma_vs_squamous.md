# Lung Adenocarcinoma vs Squamous Cell Carcinoma

## Adenocarcinoma
- glandular/acinar/papillary/lepidic/micropapillary/solid patterns,
- TTF-1/Napsin A may support adenocarcinoma lineage.

## Squamous
- keratinization/intercellular bridges,
- p40 supports squamous differentiation.

## Poorly differentiated tumors
When morphology is insufficient, a limited IHC panel is often preferred over an indiscriminate large panel.

## Sources
- PMC Lung IHC Best Practices: https://pmc.ncbi.nlm.nih.gov/articles/PMC6422775/
- NCBI Lung Adenocarcinoma: https://www.ncbi.nlm.nih.gov/books/NBK519578/
- NCBI Squamous Cell Lung Cancer: https://www.ncbi.nlm.nih.gov/books/NBK564510/
