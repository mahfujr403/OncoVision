# Lung Benign Tissue vs Lung Adenocarcinoma

## Benign tendency
- preserved alveolar architecture,
- thin septa,
- normal pneumocytes,
- normal airway structures.

## Adenocarcinoma tendency
- malignant epithelial proliferation,
- glandular/acinar/papillary/lepidic/micropapillary/solid patterns,
- atypical cells and architectural distortion.

## Caveat
Reactive pneumocytes can be atypical. A small patch can be insufficient to distinguish reactive change from carcinoma.

## Sources
- NCBI Histology, Lung: https://www.ncbi.nlm.nih.gov/books/NBK534789/
- NCBI Lung Adenocarcinoma: https://www.ncbi.nlm.nih.gov/books/NBK519578/
