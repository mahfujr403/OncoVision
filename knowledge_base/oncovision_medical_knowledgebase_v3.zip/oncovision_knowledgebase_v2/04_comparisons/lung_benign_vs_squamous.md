# Lung Benign Tissue vs Squamous Cell Carcinoma

## Benign tendency
- preserved alveolar/airway structures,
- no destructive malignant squamous proliferation.

## Squamous tendency
- squamous differentiation,
- keratinization,
- intercellular bridges,
- possible keratin pearls.

## Caveat
Reactive squamous metaplasia can complicate interpretation. Location alone is insufficient.

## Sources
- NCBI Histology, Lung: https://www.ncbi.nlm.nih.gov/books/NBK534789/
- NCBI Squamous Cell Lung Cancer: https://www.ncbi.nlm.nih.gov/books/NBK564510/
