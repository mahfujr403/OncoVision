# Immunohistochemistry (IHC)

## Concept
IHC uses antibodies to detect specific proteins in tissue. It is an ancillary method that complements morphology.

## Lung differential
For a poorly differentiated non-small-cell carcinoma, a focused panel can help distinguish adenocarcinoma from squamous differentiation. TTF-1 and p40 are commonly used core markers in this context; Napsin A can provide additional support for adenocarcinoma.

## Colon context
Markers such as CK7, CK20, CDX2 and SATB2 can be used in appropriate differential-diagnostic contexts, but marker interpretation depends on morphology and clinical context.

## Critical caution
No single marker is an absolute diagnostic truth in every case. Focal/weak staining, specimen type, technical factors and tumor heterogeneity matter.

## Sources
- PMC, Best Practices Recommendations for Diagnostic IHC in Lung Cancer: https://pmc.ncbi.nlm.nih.gov/articles/PMC6422775/
- PubMed/PMC, TTF-1/Napsin A/p40/CK5 differential study: https://pmc.ncbi.nlm.nih.gov/articles/PMC4467219/
- NCI, Immunohistochemistry: https://www.cancer.gov/publications/dictionaries/cancer-terms/def/immunohistochemistry
