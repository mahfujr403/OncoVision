# Histopathology and H&E

## H&E
Hematoxylin and eosin (H&E) is the routine stain used to visualize tissue morphology. Hematoxylin highlights nuclear material; eosin provides contrast for much of the cytoplasm and extracellular matrix.

## Architecture versus cytology
Architecture describes how cells and structures are arranged within tissue. Cytology describes individual-cell features such as nuclear size, shape, chromatin, nucleoli, cytoplasmic characteristics, and polarity.

## Features often discussed in malignant tissue
- architectural distortion,
- abnormal gland formation,
- destructive stromal invasion,
- cytologic atypia,
- pleomorphism,
- hyperchromasia,
- abnormal mitotic activity,
- necrosis,
- desmoplastic stromal response.

None of these findings should be interpreted in isolation.

## Source
- NCBI Bookshelf, Principles of Cancer Pathology: https://www.ncbi.nlm.nih.gov/books/NBK13899/
- OpenStax, Epithelial Tissue: https://openstax.org/books/anatomy-and-physiology-2e/pages/4-2-epithelial-tissue
