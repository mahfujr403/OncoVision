# Grade, Stage, TNM

## Grade
Histologic grade describes how abnormal tumor cells/tissue look and, depending on tumor type, may incorporate differentiation and mitotic/proliferative features.

## Stage
Cancer stage describes the extent of disease. TNM commonly represents:
- T: primary tumor extent,
- N: regional lymph-node involvement,
- M: distant metastasis.

## Critical RAG boundary
H&E patch classification is not equivalent to staging. A small image patch cannot reliably establish TNM stage because stage depends on anatomic extent and other clinical/pathologic information.

## Sources
- NCI, Cancer Staging: https://www.cancer.gov/about-cancer/diagnosis-staging/staging
- NCI, Cancer Diagnosis: https://www.cancer.gov/about-cancer/diagnosis-staging/diagnosis
- NCI, Colon Cancer PDQ: https://www.cancer.gov/types/colorectal/hp/colon-treatment-pdq
- NCI, NSCLC PDQ: https://www.cancer.gov/types/lung/hp/non-small-cell-lung-treatment-pdq
