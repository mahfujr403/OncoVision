# Biomarkers and Molecular Testing

## What is a biomarker?
A biomarker is a biological molecule or characteristic that can provide information about a normal or abnormal process, a disease, or response to treatment.

## Testing methods
Depending on the clinical question, testing may use:
- immunohistochemistry (IHC),
- PCR-based assays,
- sequencing,
- fluorescence in situ hybridization (FISH),
- other molecular assays.

## Important lung examples
Depending on disease setting and guideline version, clinically relevant alterations can include EGFR, ALK, ROS1, BRAF, KRAS, MET, RET, NTRK, HER2 and PD-L1.

## Important colorectal examples
MMR/MSI status is clinically important. Molecular testing can include RAS genes, BRAF and other biomarkers depending on disease setting.

## Critical boundary
H&E morphology may suggest a lineage or trigger ancillary testing, but the AI should never state that a molecular mutation or biomarker is present solely from an H&E patch unless that information is explicitly provided in a pathology/laboratory result.

## Sources
- NCI Biomarker: https://www.cancer.gov/publications/dictionaries/cancer-terms/def/biomarker
- NCI Biomarker Testing: https://www.cancer.gov/publications/dictionaries/cancer-terms/def/biomarker-testing
- NCI Tumor Markers: https://www.cancer.gov/about-cancer/diagnosis-staging/diagnosis/tumor-markers-fact-sheet
- NCI NSCLC PDQ: https://www.cancer.gov/types/lung/hp/non-small-cell-lung-treatment-pdq
- NCI Colon Cancer PDQ: https://www.cancer.gov/types/colorectal/hp/colon-treatment-pdq
