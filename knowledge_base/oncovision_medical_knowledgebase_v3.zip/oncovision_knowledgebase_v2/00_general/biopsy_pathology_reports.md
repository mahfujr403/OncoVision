# Biopsy and Pathology Reports

## Why specimen context matters
A biopsy may sample only a small part of a lesion. A resection can provide information about:
- tumor size,
- depth of invasion,
- margins,
- lymph nodes,
- lymphovascular or perineural invasion,
- additional histologic components.

## Synoptic reporting
CAP cancer protocols standardize essential data elements in pathology reporting. This is useful for understanding what a complete cancer pathology report may contain.

## Key caution for OncoVision
An image patch generally cannot provide all information required for a synoptic pathology report. Do not fabricate:
- tumor size,
- margins,
- lymph-node status,
- T/N/M category,
- lymphovascular invasion,
- molecular status,
- resection completeness.

## Sources
- CAP Current Cancer Protocols: https://www.cap.org/protocols-and-guidelines/cancer-reporting-tools/cancer-protocol-templates
- NCI, Pathology Reports: https://www.cancer.gov/about-cancer/diagnosis-staging/diagnosis/pathology-reports-fact-sheet
