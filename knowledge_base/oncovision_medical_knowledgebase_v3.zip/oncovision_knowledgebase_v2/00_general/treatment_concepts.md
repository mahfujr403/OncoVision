# Treatment Concepts — Educational Only

Cancer treatment may include surgery, radiation therapy, chemotherapy, immunotherapy, targeted therapy, or combinations. Selection depends on cancer type, stage, biomarkers, patient factors, prior treatment and other clinical details.

## OncoVision rule
The RAG assistant may explain what a treatment category means in general. It should not recommend a treatment for an individual patient based on an image classification.

## Sources
- NCI Types of Cancer Treatment: https://www.cancer.gov/about-cancer/treatment/types
- NCI Colon Cancer PDQ: https://www.cancer.gov/types/colorectal/hp/colon-treatment-pdq
- NCI NSCLC PDQ: https://www.cancer.gov/types/lung/hp/non-small-cell-lung-treatment-pdq
