# Cancer and Tumor Basics

## Core concepts
Cancer is a disease in which abnormal cells divide without normal control and can invade nearby tissues or spread to distant sites. A tumor is an abnormal mass of tissue; tumors can be benign or malignant. Carcinoma is a malignant tumor arising from epithelial cells. Adenocarcinoma is a carcinoma showing glandular differentiation or arising from gland-forming epithelium.

## Histopathology relevance
Histopathology evaluates tissue architecture and cellular morphology, usually after biopsy or resection. H&E sections can show:
- tissue organization and architecture,
- nuclear and cytoplasmic morphology,
- gland formation,
- keratinization,
- necrosis,
- stromal response,
- invasion patterns.

## Important distinction
A histologic image classification label is not equivalent to a complete clinical diagnosis. Diagnosis may require clinical history, specimen adequacy, morphology at multiple levels, ancillary stains, molecular tests, imaging, and expert pathology interpretation.

## Source
- NCI, What Is Cancer? https://www.cancer.gov/about-cancer/understanding/what-is-cancer
- NCBI Bookshelf, Principles of Cancer Pathology: https://www.ncbi.nlm.nih.gov/books/NBK13899/
