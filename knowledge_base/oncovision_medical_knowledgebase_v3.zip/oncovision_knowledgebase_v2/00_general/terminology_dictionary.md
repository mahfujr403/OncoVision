# Terminology Dictionary for Retrieval

- adenocarcinoma: malignant epithelial neoplasm with glandular differentiation.
- benign: non-malignant; in this dataset label, refers to the dataset's benign tissue category and is not a guarantee that every possible lesion is absent.
- carcinoma: malignant neoplasm of epithelial origin.
- dysplasia: abnormal epithelial development/maturation; severity and significance depend on organ and lesion type.
- H&E: hematoxylin and eosin stain.
- histology: study/description of tissue structure.
- IHC: immunohistochemistry.
- invasion: extension of malignant cells into surrounding tissue compartments.
- keratinization: production/accumulation of keratin by squamous cells.
- lymphovascular invasion: tumor cells identified within lymphatic and/or vascular spaces.
- metastasis: spread of cancer to a distant site.
- mucin: glycoprotein-rich secretion produced by mucinous cells.
- necrosis: cell/tissue death.
- pleomorphism: variation in cell and/or nuclear size and shape.
- p40: squamous-lineage IHC marker used in lung carcinoma subtyping.
- TTF-1: transcription factor used as a marker supporting pulmonary adenocarcinoma lineage in the appropriate context.
- Napsin A: marker that can support lung adenocarcinoma in an appropriate panel.
- TNM: tumor-node-metastasis staging framework.

## Sources
- NCI Cancer Dictionary: https://www.cancer.gov/publications/dictionaries/cancer-terms
- NCBI Bookshelf: https://www.ncbi.nlm.nih.gov/books/NBK13899/
