# Lung Cancer Molecular and Biomarker Context

## Actionable alterations
Modern NSCLC evaluation may include molecular testing for alterations such as:
- EGFR,
- ALK,
- ROS1,
- BRAF,
- KRAS G12C,
- MET exon 14 skipping,
- RET,
- NTRK,
- HER2,
and assessment of PD-L1 in relevant clinical settings.

## Why this is separate from image classification
These biomarkers are laboratory/clinical results. H&E morphology can support histologic classification but does not directly prove a mutation or expression status.

## Source
- NCBI StatPearls Lung Adenocarcinoma: https://www.ncbi.nlm.nih.gov/books/NBK519578/
- NCI NSCLC PDQ: https://www.cancer.gov/types/lung/hp/non-small-cell-lung-treatment-pdq
- NCI Biomarker Testing: https://www.cancer.gov/publications/dictionaries/cancer-terms/def/biomarker-testing
