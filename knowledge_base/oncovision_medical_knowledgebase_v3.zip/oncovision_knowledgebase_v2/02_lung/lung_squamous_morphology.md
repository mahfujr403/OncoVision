# Lung Squamous Cell Carcinoma — Histomorphology

## Core features
Pulmonary squamous cell carcinoma is an NSCLC subtype. Histologic differentiation can include:
- keratinization,
- intercellular bridges,
- squamous maturation,
- keratin pearls in differentiated tumors.

Poorly differentiated tumors may have little obvious keratinization.

## Major variants
Commonly described variants include:
- keratinizing,
- nonkeratinizing,
- basaloid.

## Location is not a diagnosis
Squamous cell carcinoma often occurs centrally, but location alone cannot establish histology. Likewise, adenocarcinoma can occur in peripheral lung.

## Sources
- NCBI StatPearls, Squamous Cell Lung Cancer: https://www.ncbi.nlm.nih.gov/books/NBK564510/
- NCI NSCLC PDQ: https://www.cancer.gov/types/lung/hp/non-small-cell-lung-treatment-pdq
