# Normal Lung Microanatomy

## Conducting and respiratory portions
The respiratory tree includes trachea, bronchi, bronchioles, respiratory bronchioles, alveolar ducts, alveolar sacs and alveoli.

## Alveoli
Alveoli are the main gas-exchange structures. Type I pneumocytes form most of the thin gas-exchange surface. Type II pneumocytes produce pulmonary surfactant and can participate in epithelial repair. Alveolar macrophages may be present in airspaces.

## Bronchi and bronchioles
Bronchi contain supporting cartilage and smooth muscle; bronchioles lack cartilage and have smooth-muscle-rich walls. The epithelium changes along the airway.

## Why this matters for benign-lung retrieval
Normal/benign lung patches may show alveolar spaces, thin septa, bronchiolar/airway structures, vessels and macrophages. Their appearance varies by anatomic region and sectioning.

## Sources
- NCBI StatPearls, Histology, Lung: https://www.ncbi.nlm.nih.gov/books/NBK534789/
- OpenStax, Epithelial Tissue: https://openstax.org/books/anatomy-and-physiology-2e/pages/4-2-epithelial-tissue
