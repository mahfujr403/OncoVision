# Lung Adenocarcinoma — Patterns and Differential Diagnosis

## Lepidic
Tumor cells grow along pre-existing alveolar structures without destroying the underlying architecture in the classic lepidic concept.

## Acinar
Glandular/acinar structures are present.

## Papillary
Tumor cells form papillary structures around fibrovascular cores.

## Micropapillary
Small tufts or cell clusters can be present without a central fibrovascular core; this pattern has important prognostic associations in appropriate tumors.

## Solid
Predominantly solid tumor areas lack obvious glandular architecture and may require IHC for classification.

## Main differential
The most important dataset-level lung carcinoma differential is adenocarcinoma versus squamous cell carcinoma. Poorly differentiated NSCLC may require a limited IHC panel.

## Sources
- NCBI StatPearls Lung Adenocarcinoma: https://www.ncbi.nlm.nih.gov/books/NBK519578/
- PMC Best Practices Diagnostic IHC in Lung Cancer: https://pmc.ncbi.nlm.nih.gov/articles/PMC6422775/
