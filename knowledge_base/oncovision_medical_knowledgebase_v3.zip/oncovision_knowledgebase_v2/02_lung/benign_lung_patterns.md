# Benign Lung Tissue — Histologic Patterns

## Typical structures
Depending on the patch, benign lung tissue may include:
- open alveolar spaces,
- delicate alveolar septa,
- type I/II pneumocytes,
- alveolar macrophages,
- bronchiolar epithelium,
- small blood vessels,
- connective tissue.

## Important caution
"Benign lung tissue" in LC25000 is a dataset label. It should not be interpreted as "the patient has no lung disease." Inflammation, infection, edema, fibrosis or other non-neoplastic changes may be outside the dataset's intended label distribution.

## Sources
- NCBI StatPearls, Histology, Lung: https://www.ncbi.nlm.nih.gov/books/NBK534789/
- LC25000 dataset description: https://arxiv.org/abs/1912.12142
- LC25000 repository: https://github.com/tampapath/lung_colon_image_set
