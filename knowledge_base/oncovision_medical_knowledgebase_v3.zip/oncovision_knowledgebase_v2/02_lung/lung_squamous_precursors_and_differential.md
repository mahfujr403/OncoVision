# Lung Squamous Cell Carcinoma — Precursors and Differential

## Squamous differentiation
Squamous differentiation is supported by characteristic morphology and, when needed, IHC.

## IHC
p40 is a preferred squamous marker in the differential diagnosis of NSCLC. p63 can be useful but is less specific than p40. CK5/6 may provide additional support.

## Differential with adenocarcinoma
A focused panel such as TTF-1 and p40 is commonly recommended when morphology alone does not classify a non-small-cell carcinoma. Napsin A may support adenocarcinoma.

## Caution
Focal/weak staining should not automatically be treated as definitive. IHC is an adjunct to morphology.

## Sources
- PMC Best Practices Recommendations for Diagnostic IHC in Lung Cancer: https://pmc.ncbi.nlm.nih.gov/articles/PMC6422775/
- PMC TTF-1/Napsin A/p40/CK5 study: https://pmc.ncbi.nlm.nih.gov/articles/PMC4467219/
