# Lung Adenocarcinoma — Histomorphology

## Core definition
Lung adenocarcinoma is a major subtype of non-small-cell lung cancer (NSCLC) and commonly shows glandular or pneumocyte-like differentiation.

## Major invasive patterns
The recognized predominant growth patterns include:
- lepidic,
- acinar,
- papillary,
- micropapillary,
- solid.

Other variants include invasive mucinous adenocarcinoma, colloid, fetal and enteric patterns.

## AIS and MIA
Adenocarcinoma in situ (AIS) and minimally invasive adenocarcinoma (MIA) are specific pathologic entities defined by size and invasion criteria. They cannot be reliably assigned from an arbitrary image patch alone.

## STAS
Spread through air spaces (STAS) is a pathologic finding in which tumor cells spread into airspaces beyond the edge of the main tumor. It is a tissue-context feature and should not be inferred from a small isolated patch without appropriate specimen context.

## Sources
- NCBI StatPearls, Lung Adenocarcinoma: https://www.ncbi.nlm.nih.gov/books/NBK519578/
- PMC, Pulmonary Adenocarcinoma Histology: https://pmc.ncbi.nlm.nih.gov/articles/PMC4367552/
- NCI NSCLC PDQ: https://www.cancer.gov/types/lung/hp/non-small-cell-lung-treatment-pdq
